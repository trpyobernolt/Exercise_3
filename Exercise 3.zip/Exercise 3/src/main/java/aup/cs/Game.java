package aup.cs;

import java.util.Random;

public class Game {
    private Wheel wheel;
    // generate outcomes of spin
    private Player player;
    private Table table;
    private int initialStake = 1000;
    private int betAmount = 15;

    public Game() {
        this.wheel = new Wheel();
        BinBuilder.buildBins(wheel);
        this.table = new Table();
        this.player = new Player(initialStake, table, wheel.getOneOutcome());
    }

    public Table getTable() {
        return table;
    }

    public Wheel getWheel() {
        return wheel;
    }

    public Bin[] getPossibleBets(){
        return this.wheel.getOneOutcome();
    }

    public void cycle(Player player) {
        //Runs one round of game
        player.placeBets(betAmount);
        Bet[] bets = table.getBets();
        Random rand = new Random();
        int chosenPlace = rand.nextInt(39);
        String chosenString = String.valueOf(chosenPlace);
        if(chosenPlace == 1) {
            chosenString = "00";
        }
        System.out.println(bets[0].getOutcome().getBin());
        for(int i = 0; i < bets.length; i++) {
            String stringBet = bets[i].getOutcome().getBin();
            System.out.println("Player placed bets on: " + stringBet);
            String[] split = stringBet.split(",");
            System.out.println("Wheel lands on " + chosenString);
            for(int x = 0; x < split.length; x++) {
                System.out.println("Player will win if wheel lands on: " + split[x]);
                if (chosenString.equals(split[x])) {
                    int added = bets[i].getBet() * bets[i].getOutcome().getPayout();
                    System.out.println("PLAYER HAS WON!!!!!!!!!!!!!!!!!!");
                    player.increaseBank(added);
                }
            }
        }
        }
    }
